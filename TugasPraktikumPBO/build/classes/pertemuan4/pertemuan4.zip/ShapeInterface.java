/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pertemuan4;

/**
 *
 * @author sye
 */
public interface ShapeInterface {
    
    void luas();
    void keliling();
}